self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ccbcf9e14443a6a135adcad14739a823",
    "url": "/index.html"
  },
  {
    "revision": "fec3eea3d0ccce8a503b",
    "url": "/static/css/main.7feeec01.chunk.css"
  },
  {
    "revision": "452382fe1f21da892a28",
    "url": "/static/js/2.dd47aa75.chunk.js"
  },
  {
    "revision": "399f53661ab9077408e82038d65f419c",
    "url": "/static/js/2.dd47aa75.chunk.js.LICENSE"
  },
  {
    "revision": "fec3eea3d0ccce8a503b",
    "url": "/static/js/main.819e8f7e.chunk.js"
  },
  {
    "revision": "ddc020d1514de00289de",
    "url": "/static/js/runtime-main.3c3a261d.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "7986e0807555a15d2562c7ca91921afa",
    "url": "/static/media/mktg-strat-report-bkgnd-100.7986e080.jpg"
  }
]);